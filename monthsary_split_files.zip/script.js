/* ===== YOU CAN EDIT THESE SETTINGS ===== */
const HER_NAME = "Love";
const MY_NAME  = "Ako";
const LETTER =
`Hi ${HER_NAME}, Happy Monthsary! 💙

Una sa lahat gusto ko sabihin na love na love kita subra. Salamat sa lahat ng pagtitiis at pagmamahal mo sa akin. 
Sorry sa mga pangangasar ko sayo at pang iinis ko sayo, pero mahal na mahal kita super. Supportahan kita sa mga bagay na gusto mo gawin lalo na sa pangarap mo love. 
At Goodluck sa duty mo always mo galingan love proud na proud ako sayo. lagi mo tatandaan na andito lang ako para sayo, sa lahat ng bagay na kailangan mo ng suporta at pagmamahal. 
At tska love pasensya na if di tayo makakapag date or celebrate ngayon love pasensya na talaga love wala kasi ako pera now pero babawi ako love magkaroon lang pera kahit ano gusto mo kainin.
Thankyou love sa always pag unawa. Iloveyouusomuch love ko and 11th monthsary love :*





Next week late date. 🌷`;
/* ======================================= */

const $ = id => document.getElementById(id);

/* ----- Build the 3D lily ----- */
const rig = $('rig');
const petals = [];
rig.insertAdjacentHTML('beforeend','<div class="stem"></div>');
for(let i=0;i<6;i++){
  const p=document.createElement('div');
  p.className='petal'+(i%2?' in':'');
  p.dataset.a=i*60;
  p.style.transform=`rotateY(${p.dataset.a}deg) rotateX(4deg)`;
  rig.appendChild(p);
  petals.push(p);
}
const stam=[];
for(let i=0;i<5;i++){
  const s=document.createElement('div');
  s.className='stamen';
  s.dataset.a=i*72;
  s.style.transform=`rotateY(${s.dataset.a}deg) rotateX(2deg)`;
  rig.appendChild(s);
  stam.push(s);
}
let opened=false;
function bloom(){
  if(opened)return;
  opened=true;
  petals.forEach((p,i)=>{
    p.style.transitionDelay=(i*0.12)+'s';
    p.style.transform=`rotateY(${p.dataset.a}deg) rotateX(${i%2?52:68}deg)`;
  });
  stam.forEach(s=>s.style.transform=`rotateY(${s.dataset.a}deg) rotateX(28deg)`);
  $('hint').classList.add('hidden');
  setTimeout(()=>$('open').classList.remove('hidden'),2200);
  burst();
}
$('scene').addEventListener('click',bloom);
setTimeout(bloom,1800);

/* Spin and tilt with the pointer */
let ry=0,drag=false,sx=0;
setInterval(()=>{if(!drag){ry+=.35;rig.style.setProperty('--ry',ry+'deg')}},30);
$('scene').addEventListener('pointerdown',e=>{drag=true;sx=e.clientX});
addEventListener('pointerup',()=>drag=false);
addEventListener('pointermove',e=>{
  if(drag){ry+=(e.clientX-sx)*.6;sx=e.clientX;rig.style.setProperty('--ry',ry+'deg')}
});

/* ----- Sparkles and falling petals ----- */
const cv=$('fx'),cx=cv.getContext('2d');
let W,H,parts=[];
function size(){W=cv.width=innerWidth;H=cv.height=innerHeight}
addEventListener('resize',size);size();
function spawn(x,y,burstMode){
  parts.push({
    x,y,r:Math.random()*3+1,
    vx:burstMode?(Math.random()-.5)*7:(Math.random()-.5)*.4,
    vy:burstMode?(Math.random()-.8)*6:-(Math.random()*.6+.2),
    life:burstMode?90:600,a:Math.random()*6
  });
}
function burst(){for(let i=0;i<60;i++)spawn(W/2,H*.35,true)}
function loop(){
  cx.clearRect(0,0,W,H);
  if(Math.random()<.25)spawn(Math.random()*W,H+10,false);
  parts=parts.filter(p=>p.life>0&&p.y>-20);
  for(const p of parts){
    p.x+=p.vx+Math.sin(p.a+=.03)*.3;
    p.y+=p.vy;p.life--;
    if(p.vx>1||p.vx<-1)p.vy+=.08;
    cx.beginPath();cx.arc(p.x,p.y,p.r,0,Math.PI*2);
    cx.fillStyle=`rgba(150,215,255,${Math.min(1,p.life/60)*.85})`;
    cx.shadowColor='#6cc4ff';cx.shadowBlur=12;cx.fill();
  }
  requestAnimationFrame(loop);
}
loop();

/* ----- Letter typewriter ----- */
function type(){
  const el=$('letter');
  let i=0;
  (function t(){
    el.textContent=LETTER.slice(0,i++);
    if(i<=LETTER.length)setTimeout(t,28);
    else{el.classList.remove('caret');setTimeout(showPick,700)}
  })();
}
$('open').addEventListener('click',()=>{
  $('letterBox').classList.remove('hidden');
  $('open').classList.add('hidden');
  $('letterBox').scrollIntoView({behavior:'smooth'});
  type();
});

/* ----- Date choices: next week, calculated from today ----- */
let choice=null,custom=false;
function showPick(){
  $('pick').classList.remove('hidden');
  $('pick').scrollIntoView({behavior:'smooth',block:'center'});
}
(function build(){
  const now=new Date();
  const toMon=((8-now.getDay())%7)||7;
  const days=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  const mon=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const box=$('chips');
  for(let i=0;i<7;i++){
    const d=new Date(now.getFullYear(),now.getMonth(),now.getDate()+toMon+i);
    const b=document.createElement('button');
    b.className='chip';
    b.textContent=`${days[d.getDay()]}, ${mon[d.getMonth()]} ${d.getDate()}`;
    b.onclick=()=>select(b,b.textContent,false);
    box.appendChild(b);
  }
  const n=document.createElement('button');
  n.className='chip wide';
  n.textContent="None of These Work for Me 😅 (I'll Choose)";
  n.onclick=()=>select(n,'',true);
  box.appendChild(n);
})();
function select(btn,text,isCustom){
  document.querySelectorAll('.chip').forEach(c=>c.classList.remove('sel'));
  btn.classList.add('sel');
  choice=text;
  custom=isCustom;
  $('customBox').classList.toggle('hidden',!isCustom);
}

let finalText='';
const RESULTS_URL='https://claude.ai/artifact/XPCfpqcuMpzHvAoSGm7vV6';
function makeLink(when,isCustom){
  const j=JSON.stringify({w:when,c:isCustom?1:0,t:Date.now()});
  const tok=btoa(unescape(encodeURIComponent(j))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
  finalText=`Hi ${MY_NAME}! I'm available on ${when} for our belated monthsary date 💙 Here's my response: ${RESULTS_URL}#${tok} I love you!`;
}

/* Optional Claude artifact database integration. This only works in an environment
   that provides the Claude artifact APIs; a normal local HTML file uses the fallback. */
let dbRef=null;
(async()=>{
  try{
    if(typeof claude==='undefined')return;
    dbRef=await claude.use('db');
    const user=await claude.use('user');
    if(dbRef&&user&&user.isOwner()){
      $('inbox').classList.remove('hidden');
      dbRef.collection('responses').orderBy('at','desc').onSnapshot(snap=>{
        const box=$('answers');box.textContent='';
        if(snap.empty){box.innerHTML='<p class="toast">They haven\'t answered yet…</p>';return}
        snap.forEach(d=>{
          const r=d.data(),p=document.createElement('p');
          p.style.cssText='margin:10px 0;padding:10px 12px;border-radius:12px;background:rgba(255,255,255,.1)';
          p.textContent=`💙 ${r.when}${r.custom?' (custom choice)':''} · ${new Date(r.at).toLocaleString('en-US')}`;
          box.appendChild(p);
        });
      },()=>{});
    }
  }catch(e){dbRef=null}
})();
async function saveAnswer(when,isCustom){
  try{
    if(typeof claude==='undefined')throw new Error('Database integration unavailable');
    if(!dbRef)dbRef=await claude.use('db');
    if(!dbRef)throw new Error('Database unavailable');
    await dbRef.collection('responses').add({when,custom:isCustom,at:Date.now()});
    $('toast').textContent='Your answer has been sent 💙';
  }catch(e){
    $('toast').textContent='Automatic sending is unavailable here. Copy or share your response and send it to them 💙';
  }
}
$('confirm').addEventListener('click',()=>{
  let when=choice;
  if(custom){
    const v=$('cdate').value,note=$('cnote').value.trim();
    if(!v){alert('Please choose a date first 💙');return}
    const d=new Date(v+'T00:00');
    when=d.toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric',year:'numeric'})+(note?` (${note})`:'');
  }
  if(!when){alert('Please choose a day first 💙');return}
  finalText=`Hi ${MY_NAME}! I'm available on ${when} for our belated monthsary date 💙 I love you!`;
  makeLink(when,custom);
  $('stamp').textContent='Answered on '+new Date().toLocaleString('en-US');
  $('result').textContent=`Our date: ${when} 🗓️💙`;
  $('pick').classList.add('hidden');
  $('end').classList.remove('hidden');
  $('end').scrollIntoView({behavior:'smooth'});
  for(let k=0;k<4;k++)setTimeout(burst,k*500);
  saveAnswer(when,custom);
});
$('copy').addEventListener('click',async()=>{
  try{
    if(navigator.clipboard&&window.isSecureContext){
      await navigator.clipboard.writeText(finalText);
      $('toast').textContent='Copied! Paste it into your chat 💙';
    }else{
      const ta=document.createElement('textarea');
      ta.value=finalText;document.body.appendChild(ta);ta.select();
      const ok=document.execCommand('copy');ta.remove();
      $('toast').textContent=ok?'Copied! Paste it into your chat 💙':'Please select and copy the response text manually: '+finalText;
    }
  }catch(e){$('toast').textContent='Copy this and send it to them: '+finalText}
});
$('share').addEventListener('click',async()=>{
  try{
    if(navigator.share){await navigator.share({text:finalText});}
    else if(navigator.clipboard&&window.isSecureContext){
      await navigator.clipboard.writeText(finalText);
      $('toast').textContent='Sharing is not supported here, so your response was copied 💙';
    }else{
      $('toast').textContent=finalText;
    }
  }catch(e){
    if(e.name!=='AbortError')$('toast').textContent='You can copy and send this: '+finalText;
  }
});
